
var PublicUserInfo = cc.Class({
    ctor: function () {
        this.userDBID = 39373906;
        this.nDiamond = 0;
        this.nickName = "";
        this.nFaceID = 0;
        this.encryptPassword = "e10adc3949ba59abbe56e057f20f883e";
        this.faceData = null;
        this.email = "";
        this.sex = 1; // 1:Male other:Female
        this.nGold = 0;
        this.vipLevel = 0;
        this.nFrag = 0;
        this.bankAmount = 0;
        this.payAmount = 0;
        this.code = 0; // 我绑定的推荐码
        this.myCode = 0;
        this.recommandID = 0;
        this.recommandName = "";
        this.bindSendDiamond = 0;
        this.paySendDiamond = 0;
        this.agentPop = 0;
        this.nRoomCard = 0;
        this.userWords = "";
        this.payLimit = 1;  //还可以再冲多少钱
        this.sBindPhone = "";  //是否绑定手机号 ""代表没有绑手机
        this.nBeanAmount = 0; //金豆
        this.nLoveliness = 0;  //魅力值

        //牌桌信息
        this.tableBoardInfo = null;

        //是否是新注册用户
       this.isNewUser = false;

    },
});


