﻿export class gamelibcommon {
    // 平台类型
    public static PLATFORM_CHINAGAMES: number = 0;	// 中游;
    public static PLATFORM_ZHONGCHUAN: number = 1;	// 中传;
    public static PLATFORM_YUEDONG: number = 2;	// 悦动;
    public static NAME_LEN: number = 32;
    public static PASS_LEN: number = 16;
    public static EMAIL_LEN: number = 32;				//閭欢缂撳啿闀垮害;
    public static PROVINCE_LEN: number = 16;			//鐪佷唤缂撳啿闀垮害;
    public static CITY_LEN: number = 16;				//鍩庡競缂撳啿闀垮害;
    public static AREA_LEN: number = 16;			//鍦板尯缂撳啿闀垮害;

    public static GAME_ROOT_LEN: number = 32;		//锟斤拷诘慊猴拷宄わ拷锟?;
    public static GAME_TYPE_LEN: number = 16;		//锟斤拷锟酵伙拷锟藉长锟斤拷;
    public static GAME_KIND_LEN: number = 16;		//锟斤拷戏锟斤拷锟藉长锟斤拷;
    public static GAME_STATION_LEN: number = 32;			//站锟姐缓锟藉长锟斤拷;
    public static GAME_SUBSTATION_LEN: number = 64;			//锟斤拷站锟斤拷锟藉长锟斤拷;
    public static GAME_ROOM_LEN: number = 32;		//锟斤拷锟戒缓锟藉长锟斤拷;
    public static GAME_MODULE_LEN: number = 16;				//锟斤拷袒锟斤拷宄わ拷锟?;
    public static URL_LEN: number = 256;			//锟斤拷址锟斤拷锟藉长锟斤拷;
    public static SERVER_LEN: number = 256;			//锟斤拷锟斤拷锟斤拷锟斤拷址锟斤拷锟斤拷;
    public static AVATAR_URL: number = 128;			//头锟斤拷锟街凤拷锟斤拷锟?;
    public static FIELE_NAME: number = 16;			//锟斤拷锟斤拷锟斤拷锟?;
    public static SCORE_BUF: number = 64;			//锟矫伙拷锟斤拷锟斤拷;
    public static ORDER_LEN: number = 16;		//锟饺硷拷锟斤拷锟斤拷;
    public static RESERVE_LEN: number = 32;			//锟斤拷锟斤拷锟斤拷锟藉长锟斤拷;
    public static PHONE_LEN: number = 16;		//全锟斤拷锟侥猴拷锟斤拷;
    public static PROP_LEAVEWORD_LEN: number = 50;			//锟斤拷锟斤拷锟斤拷锟皆筹拷锟斤拷;
    public static ACADEMY_GRADE_NAME_LEN: number = 16;			//锟斤拷锟斤拷锟斤拷院锟饺硷拷锟斤拷瞥锟斤拷锟?;
    public static CLOSE_GAME_CLIENT_MSG_LEN: number = 256;			//锟截憋拷锟斤拷戏锟酵伙拷锟斤拷时锟斤拷示锟矫伙拷锟斤拷锟斤拷息锟斤拷锟斤拷	//add by mxs;
    public static REG_RESULT_LEN: number = 256;			//注锟结返锟截碉拷锟斤拷息锟斤拷锟斤拷					//add by mxs nplaza;
    public static VNET_LEN: number = 128;			//锟斤拷锟街伙拷锟藉长锟斤拷;
    public static VNET_VALIDATE_URL_LEN: number = 1024;		//Vnet锟斤拷证Url锟斤拷锟斤拷		add by mxs 2006- 3 vnet;
    public static VNET_VALIDATE_URL_KEYWORD: number = 64;			//通锟斤拷锟斤拷锟斤拷址锟饺凤拷锟斤拷锟絍net锟斤拷锟截碉拷锟斤拷证Url;
    public static VNET_CMD_LEN: number = 256;			//Vnet锟斤拷锟斤拷锟叫碉拷陆锟斤拷锟斤拷	add by mxs e8;
    public static ENCRYPT_PASS_LEN: number = 64;				//锟斤拷锟杰碉拷锟斤拷锟诫长锟斤拷	//add by mxs vnetpass 2007- 2 - 27;

    public static MAX_USER_ID: number = 2000;	// 每个房间最多可容纳的用户数，用户ID也不应超出此范围;
    public static MAX_CHAIR: number = 6;// 最大椅子数;
    public static MAX_SCORE_BUF_LEN: number = 20;// 用户成绩的最大长度;
    public static MAX_RESERVE_LEN: number = 32;	// 何留字节最大长度;
    public static GLORY_NAME_LEN: number = 32;
    //游戏种类ID
    public static GAMEID_TENTRIX: number = 0;// 俄罗斯方块;
    public static GAMEID_24POINTS: number = 1;	// 24点;
    public static GAMEID_I_GO: number = 2;// 围棋;
    public static GAMEID_CCHESS: number = 3;// 中国象棋;
    public static GAMEID_GOBANG: number = 4;// 五子棋;
    public static GAMEID_JUNQI: number = 5;// 四国军棋;
    public static GAMEID_CHESS: number = 6;// 国际象棋;
    public static GAMEID_ANQI: number = 7;// 暗棋;
    public static GAMEID_UPGRADE: number = 8;// 升级;
    public static GAMEID_RED_HEARTS: number = 9;	// 红心大战;
    public static GAMEID_RUNOUT: number = 10;// 跑得快;
    public static GAMEID_BRIDGE: number = 11;	// 桥牌;
    public static GAMEID_MJ: number = 12;// 麻将;
    public static GAMEID_DIG: number = 13;	// 锄大D;

    public static GAMEID_DOUBLE: number = 14;	// 双扣;
    public static GAMEID_LANDLORD: number = 15;	// 斗地主;
    public static GAMEID_SHOWHAND: number = 16;	// 梭哈;
    public static GAMEID_21P: number = 17;	// 21点;
    public static GAMEID_DRAGON: number = 18;// 接龙;
    public static GAMDID_CLAMP: number = 19;// 奥塞罗;

    public static GAMEID_TESTGAME: number = 20;	// 测试游戏;

    public static GAMEID_LANLORD2P: number = 21;// 斗地主两副牌;
    public static GAMEID_DALU: number = 22;	// 大怪路子;
    public static GAMEID_FRIEND: number = 23;// 找朋友;
    public static GAMEID_CATTLE: number = 24;// 吹牛;
    public static GAMEID_BOULT: number = 25;// 筛钟;
    public static GAMEID_ANIMAL: number = 26;	// 斗兽棋;
    public static GAMEID_GOJI: number = 27;// 够级;
    public static GAMEID_TESTGAME2: number = 28;	// 测试游戏2;
    public static GAMEID_TESTGAME3: number = 29;// 测试游戏3;
    public static GAMEID_TESTGAME4: number = 30;// 测试游戏4;
    public static GAMEID_TESTGAME5: number = 31;	// 测试游戏5;
    public static GAMEID_TANK: number = 32;	// 坦克大战;
    public static GAMEID_BILLIARDS: number = 33;// 网络台球;
    public static GAMEID_BC_MJ: number = 34;// 博彩麻将;
    public static GAMEID_SANDAHA: number = 35;// 三打哈;
    public static GAMEID_CASINOSDH: number = 36;// 金币三打哈;
    public static GAMEID_BCLANDLORD: number = 37;// 金币斗地主;
    public static GAMEID_BCDIG: number = 38;// 金币锄大地;
    public static GAMEID_BJL: number = 39;

    public static GAMEID_3DBILLIARDS: number = 40;	// 3D台球;
    public static GAMEID_NEW_BILLIARDS: number = 41;	// 新台球;
    public static GAMEID_NEWSHOWHAND: number = 42;	// 梭哈;
    public static GAMEID_WAKENG: number = 43;// 挖坑;
    public static GAMEID_BAOHUANG: number = 44;	// 保皇;
    public static GAMEID_MJGUANGDONG: number = 45;	// 广东麻将;
    public static GAMEID_BCMJGUANGDONG: number = 46;// 金币广东麻将;
    public static GAMEID_NCMJ: number = 47;// 南昌麻将;
    public static GAMEID_MJCHANGSHA: number = 48;	// 长沙麻将;
    public static GAMEID_NEW21P: number = 49;// 新21点;
    public static GAMEID_CQLANDLORD: number = 50;// 重庆斗地主;
    public static GAMEID_BIGPOOL: number = 51;// 大台球;
    public static GAMEID_POOL3D16: number = 52;// 3d16球;
    public static GAMEID_CHAODIPI: number = 53;	// 抄地皮;
    public static GAMEID_GOLDFLOWER: number = 54;	// 扎金花;
    public static GAMEID_BOMBERMAN: number = 55;// 炸弹人;
    public static GAMEID_BULLETIN: number = 56;// 色盅公告;
    public static GAMEID_BULLETIN1: number = 57;	// 21点公告;
    public static GAMEID_FIVECARDS: number = 58;	// 港式五张, 梭哈;
    public static GAMEID_PLANE: number = 59;	// 飞行棋;
    public static GAMEID_ACADEMY_CCHESS: number = 60;	// 网络棋院中国象棋;
    public static GAMEID_ACADEMY_CHESS: number = 61;// 网络棋院国际象棋;
    public static GAMEID_ACADEMY_GO: number = 62;// 网络棋院围棋;
    public static GAMEID_ACADEMY_GOBANG: number = 63;// 网络棋院五子棋;
    public static GAMEID_BULLETIN2: number = 64;	// 梭哈公告;
    public static GAMEID_NEWMJGUANGDONG: number = 65;	// 新广东麻将;
    public static GAMEID_CHUZZLE: number = 66;// 鸡鸡碰;
    public static GAMEID_BALLOON: number = 67;// 气球;
    public static GAMEID_GDMJTDH: number = 68;// 广东麻将推倒胡;
    public static GAMEID_NEWGOBANG: number = 69;// 新五子棋;
    public static GAMEID_SCORE240: number = 70;// 240;
    public static GAMEID_SUPER_LANDLORD: number = 71;	// 超级斗地主;
    public static GAMEID_SUPER_MAHJONG: number = 72;// 超级麻将;
    public static GAMEID_MATCH_LANLORD: number = 73;// 斗地主比赛;
    public static GAMEID_MATCH_UPGRADE: number = 74;// 升级比赛;
    public static GAMEID_MATCH_CCHESS: number = 75;// 中国象棋比赛;
    public static GAMEID_MATCH_JUNQI: number = 76;// 军棋比赛;
    public static GAMEID_ONESANDAHA: number = 77;// 三打哈一副;
    public static GAMEID_NEWJUNQI: number = 78;// 新军旗;
    public static GAMEID_BJWAKENG: number = 79;// 宝鸡挖坑;
    public static GAMEID_PAOHUZI: number = 80;// 跑胡子;
    public static GAMEID_SANGEN: number = 81;// 三跟;
    public static GAMEID_NEWUPGRADE: number = 82;	// 新升级;
    public static GAMEID_LORDEXP: number = 83;// 超级斗地主表情版;
    public static GAMEID_SUPGRADE: number = 84;	// 超级升级;
    public static GAMEID_SGDMJ: number = 85;// 超级广东麻将;
    public static GAMEID_SUPERDIG: number = 86;	// 超级锄大地;
    public static GAMEID_DARKCHESS: number = 87;// 暗棋;
    public static TOTAL_GAME_KIND_NUM: number = 88;// 目前游戏种类数，目前就这些游戏了，玩死你;


    public static MAX_GAME_KIND_NUM: number = 256;// GAMEID的最大值;
    public static INVALID_USER_ID: number = 0xFFFF;	// 无效用户索引ID;

    public static DESCRIBE_LEN: number = 128;
    public static GROUP_LEN: number = 32;
    public static SX_BOY: number = 1;
    public static SX_GIRL: number = 0;

    public static INVALI_OFF: number = 0XFFFF;
    public static INVALI_TABLE_ID: number = 0XFFFF;
    public static INVALI_CHAIR_ID: number = 0XFF;
    public static INVALI_USER_INDEX: number = 0XFFFF;

    //友好关系
    public static FC_NORMAL: number = 0;			//普通关系;
    public static FC_FRIEND: number = 1;			//朋友关系;
    public static FC_DETEST: number = 2;			//厌恶关系;

    //用户状态定义
    public static USER_NO_STATUS: number = 0;				//没有状态;
    public static USER_FREE_STATUS: number = 1;				//在房间站;
    public static USER_WAIT_SIT: number = 2;			//等待坐下;
    public static USER_SIT_TABLE: number = 3;			//坐到座位;
    public static USER_READY_STATUS: number = 4;			//同意状态;
    public static USER_PLAY_GAME: number = 5;			//正在游戏;
    public static USER_OFF_LINE: number = 6;			//用户断线;
    public static USER_WATCH_GAME: number = 7;				//旁观游戏;

    public static isSitTable(status: number) {
        return status >= gamelibcommon.USER_SIT_TABLE && status < gamelibcommon.USER_WATCH_GAME;
    }


    public static LOOKON_ENABLE_FRIEND: number = 0x0001;	// 对朋友;
    public static LOOKON_ENABLE_ENEMY: number = 0x0002;    // 对敌人;
    public static LOOKON_ENABLE_GROUP: number = 0x0004;    // 对社团;
    public static LOOKON_ENABLE_BBRFRIEND: number = 0x0008;	// bbring好友;
    public static LOOKON_ENABLE_SAMEAREA: number = 0x0010;  // 同地区;
    public static LOOKON_ENABLE_SAMESEX: number = 0x0020;   // 同性;
    public static LOOKON_ENABLE_OPPOSITESEX: number = 0x0040;// 异性;
    public static LOOKON_ENABLE_ALL: number = 0x0080;       // 对所有人开放;
//拒绝
    public static LOOKON_DISABLE_FRIEND: number = 0x0100;	// 对朋友;
    public static LOOKON_DISABLE_ENEMY: number = 0x0200;	// 对敌人;
    public static LOOKON_DISABLE_GROUP: number = 0x0400;	// 对社团;
    public static LOOKON_DISABLE_BBRFRIEND: number = 0x0800;// bbring好友;
    public static LOOKON_DISABLE_SAMEAREA: number = 0x1000;	// 同地区;
    public static LOOKON_DISABLE_SAMESEX: number = 0x2000;	// 同性;
    public static LOOKON_DISABLE_OPPOSITESEX: number = 0x4000;	// 异性;
    public static LOOKON_DISABLE_ALL: number = 0x8000;		// 对所有人开放;

    //关注类型
    public static friendNone:number = 0;
    public static friendFriend:number = 1;
    public static friendEnemy:number = 2;

    //创建房间类型
    public static PRIVATE_ROOM_NONE: number = 0;// 无;
    public static PRIVATE_ROOM_CREATE: number = 1;// 创建;
    public static PRIVATE_ROOM_ENTER: number = 2;// 加入;


//score filed
    public static enScore_Score: number = 0;// 分数;
    public static enScore_Win: number = 1;			// 胜局;
    public static enScore_Loss: number = 2;		// 负局;
    public static enScore_Draw: number = 3;		// 和局;
    public static enScore_Flee: number = 4;		// 逃跑局数;
    public static enScore_SetCount: number = 5;		// 总局数;
    public static enScore_Bean: number = 6;			// 本周最大赢取;
    public static enScore_BeanTax: number = 7;		// 历史最大赢取;
    public static enScore_Guess: number = 8;			// 猜坑记录;

    public static enScore_Custom: number = 16;	//...鍓嶉潰鐨勪繚鐣欙紝鍚庨潰鐨勮嚜瀹氫箟;
    public static enScore_Gold: number = 17;		//閲戝竵;
    public static enScore_Tax: number = 18;			//绋?;
    public static enScore_Ranking: number = 19;			//绛夌骇鍒?;

    public static CONNECT_OK_RES:number = 0;
    public static CONNECT_ERROR_RES:number = 1;
    public static SEND_DATA_OK_RES:number = 2;
    public static SEND_DATA_ERROR_RES:number = 3;
    public static RECV_DATA_OK_RES:number = 4;
    public static RECV_DATA_ERROR_RES:number = 5;
    public static DISCONNECT_RES:number = 6;
}