
//此处定义一些全局的变量
window.G = {
    matchGameReady: null,

    goldGameReady: null,
}