export class Domain {
    public static WebRoot = "https://h5.ss2007.com:444/Platform/";//"http://jingzhou.ss2007.com/Platform/";
    public static GameWebRoot = "https://h5.ss2007.com:444/Platform/";
    public static TestWebRoot = "https://netgate.ss2007.com/Platform/";
    public static PayRoot = "https://h5.ss2007.com/NewPayMent/";
    public static AliPayRoot = "https://h5.ss2007.com/AliPay/";
    public static Phone = "4006 619 828";
    public static QQ = "2351133900";
    public static ToReplace = "h5.ss2007.com";
    public static ReplaceTo = "h5.ss2007.com";
    public static ShareRoot = "https://h5.ss2007.com/shareweb/";
    public static Weixin = "sszymj666, sszymj888";
    public static defaultHeader = "Host:" + Domain.ToReplace;

    public static WEIXIN_APPID = "wx7d30e3b46cbd4978"//"wx4fcbe111e915e93b";
    public static WEIXIN_WEB_APPID = "wx9077e9fe86b5ae1b";
    public static WEIXIN_URL = "http://scplatform.ss2007.com"
    public static PAY_GENORDER_URL = "http://scplatform.ss2007.com/weixinauth/genorder.aspx";
    //public static START_URL: string = "http://scplatform.ss2007.com/edongh5/";
    public static ENV = 0;
    public static CURRENCYTYPE = "CNY";
}
